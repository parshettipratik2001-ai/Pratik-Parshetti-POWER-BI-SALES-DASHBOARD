# EcomLens – Business at a Glance (Power BI, EU Superstore): Presenter's Guide

This guide explains the Power BI project `output/powerbi/EcomLens.pbip`. It covers how to open it, what it answers, where its numbers come from, how each visual is built and what the data says. It is written for presenting, not for engineers.

---

## 0. Opening the project

The project is a **Power BI Project (PBIP)**: a folder of text files that Power BI Desktop opens like a normal `.pbix`. The data is not packed inside, so the first open needs one refresh.

1. **Copy the folder.** Copy the whole `output/powerbi` folder to `C:\EcomLens\powerbi` on a Windows PC. It contains `EcomLens.pbip`, the `EcomLens.Report` and `EcomLens.SemanticModel` folders, and `data\eu_orders.csv`.
2. **Open it.** Double-click `EcomLens.pbip`. You need a current version of Power BI Desktop. If Desktop asks you to turn on the *Power BI Project* or *PBIR* preview features, enable them under **File → Options and settings → Options → Preview features**, restart Desktop and open the file again.
3. **Refresh.** Click **Home → Refresh**. All visuals then fill with data.
4. **Different folder?** If you put the project somewhere other than `C:\EcomLens\powerbi`, go to **Home → Transform data → Edit parameters**. Set **DataFolder** to the folder that holds `eu_orders.csv`, for example `D:\Work\powerbi\data`, then click **Refresh**.
5. **Map.** The Overview map uses the **Azure Maps** visual. If it shows a warning instead of a map, enable it under **File → Options and settings → Options → Security → Map and Filled Map visuals / Azure Maps**.
6. **Save.** Use **File → Save as** to save a `.pbix` copy for sharing.

If any visual shows an error or looks wrong, take a screenshot of it and send it over so it can be fixed in the generator script (`src/build_powerbi.py`).

---

## 1. Executive Summary

EcomLens is a six-page Power BI report about **EU Superstore**, a European retailer of office supplies, furniture and technology. It covers **4,596 orders** from **795 customers** in 15 countries between **2015 and 2018**. All money is in euros (€).

| Page | Business question it answers |
|---|---|
| **Overview** | How big is the business, is it profitable and growing, and where do sales come from? |
| **Sales** | What are the monthly, quarterly and yearly trends? Which products, categories and regions sell most? When are the peak and low months? |
| **Customers** | Who are the loyal and high-value customers? How many are churning? Are we still winning new customers? |
| **Products** | Which sub-categories and products earn the most, which get returned most, and which have stopped selling? |
| **Fulfillment** | How long does shipping take and how often is it late? |
| **Returns** | How much is returned, and where do returns concentrate? |

Every page has the same layout, matching the client's examples:

- a navy header with the page title and six page buttons,
- a row of six KPI cards,
- two rows of charts,
- a filter panel on the right with four slicers and a short "About this page" note.

---

## 2. Data & Metric Logic

### 2.1 Where the data comes from

One Excel file feeds the report: **`Sample - EU Superstore.xlsx`**. It has three sheets:

- **Orders:** one row per product line in an order. Columns include Order Date, Ship Date, Ship Mode, Customer Name, Segment (Consumer / Corporate / Home Office), Country, City, Region (Central / North / South), Category, Sub-Category, Product Name, Sales, Quantity, Discount and Profit.
- **Returns:** the Order IDs that were returned.
- **People:** the regional manager for each region.

### 2.2 How the data was prepared

A short Python script (`src/prepare_data.py`) joins the Returns sheet onto the orders, adds helper columns and writes one clean file, `data/eu_orders.csv`. Power BI loads that file.

| Helper column | What it means |
|---|---|
| **Year / Quarter / Year Month** | Taken from the order date. |
| **Is Returned** | 1 if the order appears on the Returns sheet. |
| **Returned Sales / Returned Profit** | The line's sales or profit if the order was returned, otherwise 0. |
| **Ship Days** | Days from order date to ship date. |
| **Is Delayed** | 1 if the order shipped later than its ship mode allows: Same Day over 0 days, First Class over 2, Second Class over 3, Standard Class over 5. |
| **Discount Band** | Discounts grouped as 0%, 0–10%, 10–20%, 20–40% and 40%+. |
| **Product Status** | "Stagnant" if a product sold before 2018 but **not in 2018**, otherwise "Active". |
| **Is First Order / Customer Type** | 1 and "New" on a customer's first order, then 0 and "Returning". |
| **Is Churned** | 1 if the customer's last order was more than **180 days** before 31 Dec 2018. |
| **R / F / M Score, RFM Segment** | Loyalty scoring (see 2.5). |

### 2.3 The data model

The model has three tables:

- **Orders:** the CSV, one row per order line.
- **Date:** a calendar for 2015–2018 with Year, Quarter, Month and Month Start. It is linked to Orders on Order Date, and every time chart and the Year slicer use it.
- **_Measures:** holds all the DAX measures below, grouped into folders.

The file location is held in a parameter called **DataFolder**. Helper columns that only feed calculations are hidden from the field list.

### 2.4 DAX measure glossary

Full-data values match `output/reference_numbers.md`.

**Sales folder**

| Measure | DAX | Full data |
|---|---|---|
| Sales | `SUM(Orders[Sales])` | €2,938,089 |
| Profit | `SUM(Orders[Profit])` | €372,830 |
| Profit Ratio | `DIVIDE([Profit], [Sales])` | 12.7% |
| Order Count | `DISTINCTCOUNT(Orders[Order ID])` | 4,596 |
| Avg Order Value | `DIVIDE([Sales], [Order Count])` | €639 |
| Quantity | `SUM(Orders[Quantity])` | – |
| Sales YoY % | Sales in the latest selected year compared with the year before | +36.2% (2018 vs 2017) |
| Peak Month Color | Ranks the months in view by Sales. The top 5 are colored green, the bottom 5 red and the rest grey. | – |

**Customers folder**

| Measure | DAX | Full data |
|---|---|---|
| Customers | `DISTINCTCOUNT(Orders[Customer ID])` | 795 |
| Orders per Customer | `DIVIDE([Order Count], [Customers])` | 5.8 |
| Sales per Customer | `DIVIDE([Sales], [Customers])` | €3,696 |
| Churn Rate | `DIVIDE(CALCULATE([Customers], Orders[Is Churned] = 1), [Customers])` | 26.7% |
| New Customers | `CALCULATE([Customers], Orders[Is First Order] = 1)` | – |
| Returning Customers | `CALCULATE([Customers], Orders[Is First Order] = 0)` | – |

**Products folder**

| Measure | DAX | Full data |
|---|---|---|
| Products | `DISTINCTCOUNT(Orders[Product Name])` | 1,856 |
| Stagnant Products | `CALCULATE([Products], Orders[Product Status] = "Stagnant")` | 380 |
| Avg Discount | `AVERAGE(Orders[Discount])` | – |

**Returns folder**

| Measure | DAX | Full data |
|---|---|---|
| Returned Sales | `SUM(Orders[Returned Sales])` | €204,920 |
| Returned Profit | `SUM(Orders[Returned Profit])` | – |
| Return Rate | `DIVIDE([Returned Sales], [Sales])` | 7.0% |
| Returned Orders | `CALCULATE(DISTINCTCOUNT(Orders[Order ID]), Orders[Is Returned] = 1)` | 284 |

**Fulfillment folder**

| Measure | DAX | Full data |
|---|---|---|
| Avg Ship Days | `AVERAGE(Orders[Ship Days])` | 4.0 days |
| Late Shipment Rate | `AVERAGE(Orders[Is Delayed])` (share of order lines shipped late) | 33.4% |
| Late Orders | `CALCULATE(DISTINCTCOUNT(Orders[Order ID]), Orders[Is Delayed] = 1)` | – |
| Countries | `DISTINCTCOUNT(Orders[Country])` | 15 |

### 2.5 RFM segments

Each customer is scored 1–5 on three things:

- **R (recency):** how recently they ordered. 5 is most recent.
- **F (frequency):** how many orders they placed.
- **M (monetary):** how much they spent.

The scores then place each customer in one segment:

| Segment | Rule | Customers |
|---|---|---|
| Champions | R, F and M all 4 or higher | 108 |
| Loyal | R 3+ and F 4+ | 120 |
| Potential Loyalists | R 4+ and F 2–3 | 128 |
| At Risk | R 2 or lower but F 3+ (used to buy often, now quiet) | 150 |
| Lost | R 1 and F 2 or lower | 96 |
| Hibernating | R 2 or lower and F 2 or lower | 72 |
| Promising | Everyone else | 121 |

---

## 3. Dashboard & Chart Breakdown

### Overview: "EcomLens – Business at a Glance"

- **KPIs:** Sales, Profit, Profit Ratio, Order Count, Customers, Return Rate.
- **Monthly sales (columns) and profit (line):** a combo chart.
- **Sales by year:** columns.
- **Sales by country:** Azure map with bubbles sized by sales. The tooltip shows the profit ratio.
- **Sales by segment** and **Sales by category:** donuts.
- **Sales by region:** bar chart.

### Sales Analysis

- **KPIs:** Sales, Profit, Sales YoY %, Avg Order Value, Order Count, Quantity.
- **Monthly sales, 5 peak (green) and 5 low (red) months:** the colors come from the Peak Month Color measure.
- **Sales by quarter and year:** clustered columns, one color per year.
- **Sales by category:** donut.
- **Sales by region; Profit margin by category:** bar charts.
- **Top 10 products by sales:** bar chart with a Top N filter.

### Customer Behavior

- **KPIs:** Customers, Orders per Customer, Sales per Customer, Avg Order Value, Churn Rate, Profit Ratio.
- **Customers by RFM segment:** bar chart.
- **Recency score vs frequency score:** a matrix of customer counts.
- **New vs returning customers by month:** two lines.
- **Top 10 customers by sales:** a table of sales, profit and orders.
- **Sales by segment:** columns.
- **Churn rate by region:** bar chart.

### Product Performance

- **KPIs:** Products, Stagnant Products, Quantity, Avg Discount, Return Rate, Returned Sales.
- **Sub-categories sized by sales:** tree map.
- **Sub-categories, sales vs return rate:** scatter chart with bubbles sized by quantity.
- **Profit by sub-category:** bar chart.
- **Top 10 products by sales** and **Top 10 products by returned sales:** bar charts.
- **Stagnant products (no sales in 2018):** a table of the 15 biggest by earlier sales.

### Fulfillment and Delivery

- **KPIs:** Avg Ship Days, Late Shipment Rate, Late Orders, Order Count, Quantity, Countries.
- **Avg days to ship by ship mode:** columns.
- **Late-shipment rate by region:** bar chart.
- **Orders by ship mode:** donut.
- **Late-shipment rate by month:** line.
- **Late-shipment rate by ship mode and segment:** clustered columns.

### Payments and Returns

EU Superstore has no payment fields, so this page focuses on returns and discounts.

- **KPIs:** Return Rate, Returned Sales, Returned Orders, Returned Profit, Avg Discount, Profit Ratio.
- **Return rate by month:** line.
- **Return rate by category and region:** matrix.
- **Return rate by ship mode:** bar chart.
- **Return rate by discount band:** columns.
- **Returned sales by segment:** donut.

---

## 4. Interactivity & Filters

- **Page buttons:** six buttons sit in the navy header. The current page is highlighted in blue. Click another button to jump to it; in Power BI Desktop, hold **Ctrl** while clicking.
- **Slicers:** **Year**, **Region**, **Category** and **Segment** are dropdowns in the right-hand panel. They are synced, so a choice on one page applies to every page and every KPI.
- **Cross-filtering:** clicking a bar, donut slice or map bubble filters the other visuals on that page. Click it again to clear the filter.
- **Tooltips and drill:** hovering shows exact values. Right-click a visual and choose **Show as a table** to see the numbers behind it.
- **Peak and low months, Sales YoY % and Top 10 lists** recalculate within the slicer selection. Picking only 2017, for example, shows that year's best and worst months.

---

## 5. Presentation Talking Points

1. **Strong, accelerating growth.** Sales more than doubled from €478K in 2015 to €1.04M in 2018. They grew 36% in the final year alone. All five peak months fall in 2018 and all five low months in 2015.
2. **Healthy but thin profit.** Profit is €373K, a 12.7% margin. Office Supplies earns the best margin (15.3%), Technology 13.0% and Furniture only 8.8%. **Tables lose money** (–€21K profit), the only sub-category in the red.
3. **Discounts destroy profit.** Lines with no discount earn a 25% margin. Discounts of 20–40% run at –24%, and 40%+ at –60%. A cap on discounts is the single biggest profit lever.
4. **Central region dominates.** Central brings in €1.72M of sales, against about €0.6M each for North and South. France, Germany and the United Kingdom are the top three countries.
5. **Customers are loyal.** The average customer placed 5.8 orders. Only 27% have churned (30% in the North). 150 customers are "At Risk", and they are the best target for a win-back campaign.
6. **One in three shipments is late.** First Class and Second Class are late about 40% of the time, against 32% for Standard Class and 4% for Same Day. The North has the highest late rate (37%). The fix is either to promise less or to ship faster on premium modes.
7. **Returns cost 7% of sales (€205K).** The South returns the most (9.5% of sales, against about 6% in Central and North). By category, Technology (7.4%) and Office Supplies (7.2%) return more than Furniture (6.1%).
8. **380 products have gone stagnant.** These are products with no sales in 2018. They are candidates for clearance or delisting.
9. **Limits to state up front:**
   - There is no stock data, so inventory trends cannot be shown.
   - There are no payment fields.
   - There is no return-reason field, so the report shows where returns happen but not why.
